    #include <stdio.h>  
    void main ()  
    {  
        int marks_1 = 56, marks_2 = 78, marks_3 = 88, marks_4 = 76, marks_5 = 56, marks_6 = 89;   
        float avg = (marks_1 + marks_2 + marks_3 + marks_4 + marks_5 +marks_6) / 6 ;  
	
        printf("the avarge is:%f",avg);   
    }  
