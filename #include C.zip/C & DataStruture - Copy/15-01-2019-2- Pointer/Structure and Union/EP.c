    struct Employee  
    {     
       int id;  
       char name[20];  
       struct Date  
        {  
          int dd;  
          int mm;  
          int yyyy;   
        }doj;  
    }emp1;  
